sap.ui.define([], function() {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */
		currencyValue: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		getHomeScreenImage: function(sImage) {
			return jQuery.sap.getModulePath("com.spro.uismsapui5.image") + sImage;
		},

		getImage: function(sValue) {
			return jQuery.sap.getModulePath("com.spro.uismsapui5.image");
		},

		setRowIcon: function(oValue) {
			if (!oValue) {
				return;
			}

			if (oValue["Equnr"]) {
				return "sap-icon://wrench";
			} else if (oValue["Tplnr"]) {
				return "sap-icon://functional-location";
			} else {
				return;
			}
		},

		removeLeading: function(sValue) {
			if (!sValue) {
				return;
			}
			if (sValue.match(/[a-zA-Z&^(\+|-|\*|\/|=|>|<|>=|<=|&|\||%|!|\^|\(|\))$&\.-]/)) {
				return sValue;
			} else {
				return parseInt(sValue);
			}
		}

	};

});