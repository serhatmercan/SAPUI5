/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/spro/uismsapui5/model/formatter",
	"com/spro/uismsapui5/model/models",
	"sap/ui/core/routing/History",
	"sap/ui/Device",
	"sap/m/Label",
	"sap/ui/model/Filter",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/ui/export/Spreadsheet",
	"sap/m/MessageToast"
], function(BaseController, JSONModel, formatter, models, History, Device, Label, Filter, Export, ExportTypeCSV, Spreadsheet, MessageToast) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.DowloadExcel", {

		onInit: function() {

			this._First = true;

			this._oResourceBundle = this.getResourceBundle();

			this.getRouter().getRoute("dowloadExcel").attachPatternMatched(this._onObjectMatched, this);

			this.oModel = new JSONModel();
			this.oModel.loadData(sap.ui.require.toUrl("com/spro/uismsapui5/model/PeopleData.json"), null, false);
			this.getView().setModel(this.oModel);

		},

		onDataExport: sap.m.Table.prototype.exportData || function() {

			var oModel = this.oModel;
			var oExport = new Export({

				exportType: new ExportTypeCSV({
					fileExtension: "csv",
					separatorChar: ";"
				}),

				models: oModel,

				rows: {
					path: "/items"
				},
				columns: [{
					name: "First Name",
					template: {
						content: "{firstName}"
					}
				}, {
					name: "Last name",
					template: {
						content: "{lastName}"
					}
				}, {
					name: "Job Title",
					template: {
						content: "{jobTitle}"
					}
				}, {
					name: "Location",
					template: {
						content: "{location}"
					}
				}, {
					name: "Department",
					template: {
						content: "{department}"
					}
				}]
			});
			// console.log(oExport);
			oExport.saveFile().catch(function(oError) {

			}).then(function() {
				oExport.destroy();
			});
		},

		createColumnConfig: function() {
			return [{
				label: 'firstName',
				property: 'firstName',
				width: '25'
			}, {
				label: 'lastName',
				property: 'lastName',
				width: '25'
			}, {
				label: 'jobTitle',
				property: 'jobTitle',
				width: '25'
			}, {
				label: 'location',
				property: 'location',
				width: '25'
			}, {
				label: 'department',
				property: 'department',
				width: '25'
			}];
		},
		
		onExport: function() {
			var aCols, aProducts, oSettings, oSheet;

			aCols = this.createColumnConfig();
			aProducts = this.getView().getModel().getProperty('/items');

			oSettings = {
				workbook: { columns: aCols },
				dataSource: aProducts
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build()
				.then( function() {
					MessageToast.show('Spreadsheet export has finished');
				})
				.finally(function() {
					oSheet.destroy();
				});
		},

		onAfterRendering: function() {
			if (this._First) {
				this._First = false;
			}
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});