/* global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/spro/uismsapui5/model/formatter",
	"com/spro/uismsapui5/model/models",
	"sap/ui/core/routing/History",
	"sap/ui/Device"
], function(BaseController, JSONModel, formatter, models, History, Device) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.Template", {

		formatter: formatter,

		onInit: function() {

			this._First = true;

			this._oResourceBundle = this.getResourceBundle();

			this.getRouter().getRoute("flexibleColumn").attachPatternMatched(this._onObjectMatched, this);
			
			this.oRouter = this.getOwnerComponent().getRouter();
			this._bDescendingSort = false;

		},

		onAfterRendering: function() {
			if (this._First) {
				this._First = false;
			}
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});