/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/Device"
], function(BaseController, JSONModel, History, Device) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.SmartArea", {

		onInit: function() {

			this.getRouter().getRoute("smartArea").attachPatternMatched(this._onObjectMatched, this);

/*			var oTargetModel = new JSONModel(jQuery.sap.getModulePath("com.spro.uismsapui5.model", "/StockPrices.json"));
			var oTargetSmartChart = this.getView().byId("TargetSmartChart");
			var oChartTitle = this.getView().byId("chartTitle1");
			
			// this.oTargetModel.loadData(sap.ui.require.toUrl("com/spro/uismsapui5/model/StockPrices.json"), null, false);
			
			oChartTitle = this.getView().byId("chartTitle");
			oTargetSmartChart.setChartTitle(oChartTitle);
			oTargetSmartChart.setModel(oTargetModel);*/

		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});