/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/Device"
], function(BaseController, JSONModel, History, Device) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.VizFrameCharts", {

		onInit: function() {

			this.getRouter().getRoute("vizFrameCharts").attachPatternMatched(this._onObjectMatched, this);
			
			var oData = {
				"SelectedChart": "HT-1001",
				"ChartType": [
					{
						"ChartId": "HT-1000",
						"Name": "Notebook Basic 15"
					}
				]
			};
			
			var oModel = new JSONModel(oData);
			this.getView().setModel(oModel);

		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});