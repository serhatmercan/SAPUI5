/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/spro/uismsapui5/model/formatter",
	"com/spro/uismsapui5/model/models",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/ui/Device"
], function(BaseController, JSONModel, formatter, models, MessageToast, Filter, FilterOperator, History, Device) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.IconTabBar", {

		formatter: formatter,

		onInit: function() {

			this._First = true;

			this._oResourceBundle = this.getResourceBundle();

			this.getRouter().getRoute("iconTabBar").attachPatternMatched(this._onObjectMatched, this);

			// Set Explored App's Demo Model on This Sample
			var oModel = new JSONModel(sap.ui.require.toUrl("com/spro/uismsapui5/model") + "/products.json");
			this.getView().setModel(oModel);

		},

		handleIconTabBarSelect: function(oEvent) {
			var oTable = this.byId("idProductsTable"),
				oBinding = oTable.getBinding("items"),
				sKey = oEvent.getParameter("key"),
				// Array to Combine Filters
				aFilters = [],
				oCombinedFilterG,
				oCombinedFilterKG,
				// Boarder Values for Filter
				fMaxOkWeightKG = 1,
				fMaxOkWeightG = fMaxOkWeightKG * 1000,
				fMaxHeavyWeightKG = 5,
				fMaxHeavyWeightG = fMaxHeavyWeightKG * 1000;

			if (sKey === "Ok") {
				oCombinedFilterG = new Filter([new Filter("WeightMeasure", "LT", fMaxOkWeightG), new Filter("WeightUnit", "EQ", "G")], true);
				oCombinedFilterKG = new Filter([new Filter("WeightMeasure", "LT", fMaxOkWeightKG), new Filter("WeightUnit", "EQ", "KG")], true);
				aFilters.push(new Filter([oCombinedFilterKG, oCombinedFilterG], false));
			} else if (sKey === "Heavy") {
				oCombinedFilterG = new Filter([new Filter("WeightMeasure", "BT", fMaxOkWeightG, fMaxHeavyWeightG), new Filter("WeightUnit", "EQ",
					"G")], true);
				oCombinedFilterKG = new Filter([new Filter("WeightMeasure", "BT", fMaxOkWeightKG, fMaxHeavyWeightKG), new Filter("WeightUnit",
					"EQ", "KG")], true);
				aFilters.push(new Filter([oCombinedFilterKG, oCombinedFilterG], false));
			} else if (sKey === "Overweight") {
				oCombinedFilterKG = new Filter([new Filter("WeightMeasure", "GT", fMaxHeavyWeightKG), new Filter("WeightUnit", "EQ", "KG")], true);
				oCombinedFilterG = new Filter([new Filter("WeightMeasure", "GT", fMaxHeavyWeightG), new Filter("WeightUnit", "EQ", "G")], true);
				aFilters.push(new Filter([oCombinedFilterKG, oCombinedFilterG], false));
			}
			oBinding.filter(aFilters);
		},

		onAfterRendering: function() {
			if (this._First) {
				this._First = false;
			}
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});