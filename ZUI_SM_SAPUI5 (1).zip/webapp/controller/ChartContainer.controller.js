/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/spro/uismsapui5/model/formatter",
	"com/spro/uismsapui5/model/models",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/ui/Device",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/controls/common/feeds/FeedItem",
	"sap/m/ColumnListItem",
	"sap/m/library",
	"sap/m/Label",
	"sap/m/Column"
], function(BaseController, JSONModel, formatter, models, MessageToast, Filter, FilterOperator, History, Device, FlattenedDataset,
	FeedItem, ColumnListItem, MobileLibrary, Label, Column) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.ChartContainer", {

		_constants: {
			sampleName: "com.spro.uismsapui5.model",
			vizFrame: {
				id: "chartContainerVizFrame",
				dataset: {
					dimensions: [{
						name: 'Country',
						value: "{Country}"
					}],
					measures: [{
						group: 1,
						name: 'Profit',
						value: '{Revenue2}'
					}, {
						group: 1,
						name: 'Target',
						value: '{Target}'
					}, {
						group: 1,
						name: "Forcast",
						value: "{Forcast}"
					}, {
						group: 1,
						name: "Revenue",
						value: "{Revenue}"
					}, {
						group: 1,
						name: 'Revenue2',
						value: '{Revenue2}'
					}, {
						group: 1,
						name: "Revenue3",
						value: "{Revenue3}"
					}],
					data: {
						path: "/Products"
					}
				},
				modulePath: "/ChartContainerData1.json",
				type: "line",
				properties: {
					plotArea: {
						showGap: true
					}
				},
				feedItems: [{
					'uid': "primaryValues",
					'type': "Measure",
					'values': ["Revenue"]
				}, {
					'uid': "axisLabels",
					'type': "Dimension",
					'values': ["Country"]
				}, {
					'uid': "targetValues",
					'type': "Measure",
					'values': ["Target"]
				}]
			},
			table: {
				modulePath: "/ChartContainerData2.json",
				itemBindingPath: "/businessData",
				columnLabelTexts: ["Sales Month", "Marital Status", "Customer Gender", "Sales Quarter", "Cost", "Unit Price", "Gross Profit",
					"Sales Revenue"
				],
				templateCellLabelTexts: ["{Sales_Month}", "{Marital Status}", "{Customer Gender}", "{Sales_Quarter}", "{Cost}", "{Unit Price}",
					"{Gross Profit}", "{Sales Revenue}"
				]
			}
		},

		onInit: function() {

			this._First = true;

			this._oResourceBundle = this.getResourceBundle();

			this.getRouter().getRoute("chartContainer").attachPatternMatched(this._onObjectMatched, this);

			// Create Table Content
			var oTable = this.getView().byId("idTable");
			this._createTableContent(oTable);

			// Create Chart Content
			var oVizFrame = this.getView().byId(this._constants.vizFrame.id);
			this._updateVizFrame(oVizFrame);

		},

		_createTableContent: function(oTable) {
			var oTablePath = jQuery.sap.getModulePath(this._constants.sampleName, this._constants.table.modulePath);
			var oTableModel = new JSONModel(oTablePath);
			var oTableConfig = this._constants.table;
			var aColumns = this._createTableColumns(oTableConfig.columnLabelTexts);

			for (var i = 0; i < aColumns.length; i++) {
				oTable.addColumn(aColumns[i]);
			}

			var oTableItemTemplate = new ColumnListItem({
				type: MobileLibrary.ListType.Active,
				cells: this._createLabels(oTableConfig.templateCellLabelTexts)
			});

			oTable.bindItems(oTableConfig.itemBindingPath, oTableItemTemplate, null, null);
			oTable.setModel(oTableModel);
		},

		_createTableColumns: function(labels) {
			var aLabels = this._createLabels(labels);
			return this._createControls(Column, "header", aLabels);
		},

		_createLabels: function(labelTexts) {
			return this._createControls(Label, "text", labelTexts);
		},

		_createControls: function(Control, prop, propValues) {
			var aControls = [];
			var oProps = {};
			for (var i = 0; i < propValues.length; i++) {
				oProps[prop] = propValues[i];
				aControls.push(new Control(oProps));
			}
			return aControls;
		},

		_updateVizFrame: function(vizFrame) {
			var oVizFrame = this._constants.vizFrame;
			var oVizFramePath = jQuery.sap.getModulePath(this._constants.sampleName, oVizFrame.modulePath);
			var oModel = new JSONModel(oVizFramePath);
			var oDataset = new FlattenedDataset(oVizFrame.dataset);

			vizFrame.setVizProperties(oVizFrame.properties);
			vizFrame.setDataset(oDataset);
			vizFrame.setModel(oModel);
			this._addFeedItems(vizFrame, oVizFrame.feedItems);
			vizFrame.setVizType(oVizFrame.type);
		},

		_addFeedItems: function(vizFrame, feedItems) {
			for (var i = 0; i < feedItems.length; i++) {
				vizFrame.addFeed(new FeedItem(feedItems[i]));
			}
		},

		onAfterRendering: function() {
			if (this._First) {
				this._First = false;
			}
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});