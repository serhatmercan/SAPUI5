/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/Device"
], function(BaseController, JSONModel, History, Device) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.DataBinding", {

		_data: {
			"number": ["99.99", "$"],
			"date": new Date(),
			"dtValue": new Date(),
			"floatNumber": "123.456",
			"intNumber": "123",
			"time": new Date()
		},

		onInit: function() {

			this.getRouter().getRoute("dataBinding").attachPatternMatched(this._onObjectMatched, this);

			var oModel = new JSONModel(this._data);
			this.getView().setModel(oModel);

		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});