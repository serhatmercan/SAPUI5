/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/spro/uismsapui5/model/formatter",
	"com/spro/uismsapui5/model/models",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/ui/Device"
], function(BaseController, JSONModel, formatter, models, MessageToast, Filter, FilterOperator, History, Device) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.ObjectPage", {

		formatter: formatter,

		onInit: function() {

			this._First = true;
			this._oResourceBundle = this.getResourceBundle();
			this.getRouter().getRoute("objectPage").attachPatternMatched(this._onObjectMatched, this);

		},

		onAfterRendering: function() {
			if (this._First) {
				this._First = false;
			}
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});