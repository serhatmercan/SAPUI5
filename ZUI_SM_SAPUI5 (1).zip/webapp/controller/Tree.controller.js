/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/Device"
], function(BaseController, JSONModel, History, Device) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.Tree", {

		onInit: function() {

			this.getRouter().getRoute("tree").attachPatternMatched(this._onObjectMatched, this);

			// Set Explored App's Demo Model on This Sample
			var oModel = new JSONModel(sap.ui.require.toUrl("com/spro/uismsapui5/model") + "/Tree.json");
			this.getView().setModel(oModel);
			this.byId("Tree").expandToLevel(1);
		},

		handleSelectChangeMode: function(oEvent) {
			var mode = oEvent.getParameter("selectedItem").getKey();
			this.byId("Tree").setMode(mode);
		},

		handleSelectChangeLevel: function(oEvent) {
			var iLevel = oEvent.getParameter("selectedItem").getKey();
			this.byId("Tree").expandToLevel(iLevel);
		},

		onCollapseAllPress: function(evt) {
			var oTree = this.byId("Tree");
			oTree.collapseAll();
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});