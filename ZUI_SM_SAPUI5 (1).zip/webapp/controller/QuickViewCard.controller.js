/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/Device"
], function(BaseController, JSONModel, History, Device) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.QuickViewCard", {

		_mData: null,
		_oModel: null,

		onInit: function() {

			this.getRouter().getRoute("quickViewCard").attachPatternMatched(this._onObjectMatched, this);

			// Create JSON Model Instance
			this._oModel = new JSONModel();

			// JSON sample data
			var mData = {
				pages: [{
					pageId: "companyPageId",
					header: "Company info",
					title: "Adventure Company",
					titleUrl: "http://sap.com",
					icon: "sap-icon://building",
					description: "John Doe",
					groups: [{
						heading: "Contact Details",
						elements: [{
							label: "Phone",
							value: "+001 6101 34869-0",
							elementType: sap.m.QuickViewGroupElementType.phone
						}, {
							label: "Address",
							value: "550 Larkin Street, 4F, Mountain View, CA, 94102 San Francisco USA",
							elementType: sap.m.QuickViewGroupElementType.text
						}]
					}, {
						heading: "Main Contact",
						elements: [{
							label: "Name",
							value: "John Doe",
							elementType: sap.m.QuickViewGroupElementType.pageLink,
							pageLinkId: "companyEmployeePageId"
						}, {
							label: "Mobile",
							value: "+001 6101 34869-0",
							elementType: sap.m.QuickViewGroupElementType.mobile
						}, {
							label: "Phone",
							value: "+001 6101 34869-0",
							elementType: sap.m.QuickViewGroupElementType.phone
						}, {
							label: "Email",
							value: "main.contact@company.com",
							emailSubject: 'Subject',
							elementType: sap.m.QuickViewGroupElementType.email
						}]
					}]
				}, {
					pageId: "companyEmployeePageId",
					header: "Employee Info",
					title: "John Doe",
					icon: "sap-icon://person-placeholder",
					description: "Department Manager",
					groups: [{
						heading: "Company",
						elements: [{
							label: "Name",
							value: "Adventure Company",
							url: "http://sap.com",
							elementType: sap.m.QuickViewGroupElementType.link
						}, {
							label: "Address",
							value: "Sofia, Boris III, 136A"
						}, {
							label: "Slogan",
							value: "Innovation through technology"
						}]
					}, {
						heading: "Other",
						elements: [{
							label: "Email",
							value: "john.doe@sap.com",
							emailSubject: 'Subject',
							elementType: sap.m.QuickViewGroupElementType.email
						}, {
							label: "Phone",
							value: "+359 888 888 888",
							elementType: sap.m.QuickViewGroupElementType.mobile
						}]
					}]
				}]
			};

			this._mData = mData;

			// Set the Data for the Model
			this._oModel.setData(this._mData);
			this.getView().setModel(this._oModel);

		},

		onHeaderSwitchChange: function(oEvent) {
			if (oEvent.getParameters().state) {
				this._mData.pages[0].title = "Adventure Company";
				this._mData.pages[0].icon = "sap-icon://building";
				this._mData.pages[0].description = "John Doe";
			} else {
				this._mData.pages[0].title = "";
				this._mData.pages[0].icon = "";
				this._mData.pages[0].description = "";
			}

			this._oModel.setData(this._mData);
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});