/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/Device",
	"com/spro/uismsapui5/model/formatter"
], function(BaseController, JSONModel, History, Device, formatter) {
	"use strict";
	
	return BaseController.extend("com.spro.uismsapui5.controller.TreeTable", {

		formatter: formatter,

		onInit: function() {

			this.getRouter().getRoute("treeTable").attachPatternMatched(this._onObjectMatched, this);

		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});