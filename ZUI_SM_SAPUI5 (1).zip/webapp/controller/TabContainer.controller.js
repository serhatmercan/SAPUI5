/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"com/spro/uismsapui5/model/formatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/Device",
	"sap/m/MessageToast",
	"sap/m/TabContainerItem",
	"sap/m/MessageBox"
], function(BaseController, formatter, JSONModel, History, Device, MessageToast, TabContainerItem, MessageBox) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.TabContainer", {

		formatter: formatter,

		onInit: function() {

			this.getRouter().getRoute("tabContainer").attachPatternMatched(this._onObjectMatched, this);

			var oModel = new JSONModel();
			oModel.setData({
				employees: [{
					name: "Jean Doe",
					empFirstName: "Jean",
					empLastName: "Doe",
					position: "Senior Developer",
					icon: "../image/Woman_04.png",
					iconTooltip: "group",
					salary: 1455.22
				}, {
					name: "John Smith",
					empFirstName: "John",
					empLastName: "Smith",
					position: "Developer",
					icon: "sap-icon://notes",
					iconTooltip: "notes",
					salary: 1390.77,
					modified: true
				}, {
					name: "Particia Clark",
					empFirstName: "Particia",
					empLastName: "Clark",
					position: "Developer",
					icon: "sap-icon://group",
					iconTooltip: "group",
					salary: 1189.00
				}, {
					name: "Tim McAfeed",
					empFirstName: "Tim",
					empLastName: "McAfeed",
					position: "Junior Developer",
					icon: "sap-icon://group",
					iconTooltip: "group",
					salary: 1235.37
				}]
			});
			this.getView().setModel(oModel);

		},

		onItemSelected: function(oEvent) {
			var oItem = oEvent.getSource();
			MessageToast.show(
				"Item " + oItem.getName() + " was selected"
			);
		},
		addNewButtonPressHandler: function() {
			var newEmployee = new TabContainerItem({
				name: "New employee",
				additionalText: "Developer",
				icon: "sap-icon://group",
				iconTooltip: "group",
				modified: false
			});

			var tabContainer = this.byId("myTabContainer");

			tabContainer.addItem(
				newEmployee
			);
			tabContainer.setSelectedItem(
				newEmployee
			);
		},

		itemCloseHandler: function(oEvent) {
			// Prevent the Tab Being Closed by Default
			oEvent.preventDefault();

			var oTabContainer = this.byId("myTabContainer");
			var oItemToClose = oEvent.getParameter("item");

			MessageBox.confirm("Do you want to close the tab '" + oItemToClose.getName() + "'?", {
				onClose: function(oAction) {
					if (oAction === MessageBox.Action.OK) {
						oTabContainer.removeItem(oItemToClose);
						MessageToast.show("Item closed: " + oItemToClose.getName(), {
							duration: 500
						});
					} else {
						MessageToast.show("Item close canceled: " + oItemToClose.getName(), {
							duration: 500
						});
					}
				}
			});
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});