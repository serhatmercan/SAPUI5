/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/spro/uismsapui5/model/formatter",
	"com/spro/uismsapui5/model/models",
	"sap/ui/core/routing/History",
	"sap/ui/Device",
	"sap/ui/core/format/DateFormat",
	"sap/base/Log"
], function(BaseController, JSONModel, formatter, models, History, Device, DateFormat, Log) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.DynamicPage", {

		onInit: function() {

			this._First = true;

			this._oResourceBundle = this.getResourceBundle();

			this.getRouter().getRoute("dynamicPage").attachPatternMatched(this._onObjectMatched, this);
			
			var oJSONModel = this.initSampleDataModel();
			this.getView().setModel(oJSONModel);

		},
		
		initSampleDataModel : function() {
			var oModel = new JSONModel();

			var oDateFormat = DateFormat.getDateInstance({source: {pattern: "timestamp"}, pattern: "dd/MM/yyyy"});

			jQuery.ajax(sap.ui.require.toUrl("com/spro/uismsapui5/model") + "/Products.json", {
				dataType: "json",
				success: function (oData) {
					var aTemp1 = [];
					var aTemp2 = [];
					var aSuppliersData = [];
					var aCategoryData = [];
					for (var i = 0; i < oData.ProductCollection.length; i++) {
						var oProduct = oData.ProductCollection[i];
						if (oProduct.SupplierName && jQuery.inArray(oProduct.SupplierName, aTemp1) < 0) {
							aTemp1.push(oProduct.SupplierName);
							aSuppliersData.push({Name: oProduct.SupplierName});
						}
						if (oProduct.Category && jQuery.inArray(oProduct.Category, aTemp2) < 0) {
							aTemp2.push(oProduct.Category);
							aCategoryData.push({Name: oProduct.Category});
						}
						oProduct.DeliveryDate = (new Date()).getTime() - (i % 10 * 4 * 24 * 60 * 60 * 1000);
						oProduct.DeliveryDateStr = oDateFormat.format(new Date(oProduct.DeliveryDate));
						oProduct.Heavy = oProduct.WeightMeasure > 1000 ? "true" : "false";
						oProduct.Available = oProduct.Status === "Available";
					}

					oData.Suppliers = aSuppliersData;
					oData.Categories = aCategoryData;
					oData.headerExpanded = true;
					oModel.setData(oData);
				},
				error: function () {
					Log.error("failed to load json");
				}
			});

			return oModel;
		},

		formatAvailableToObjectState: function(bAvailable) {
			return bAvailable ? "Success" : "Error";
		},

		formatAvailableToIcon: function(bAvailable) {
			return bAvailable ? "sap-icon://accept" : "sap-icon://decline";
		},

		onGenericTagPress: function (oEvent) {
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("com.spro.uismsapui5.fragment.Card", this);
				this.getView().addDependent(this._oPopover);
			}
			this._oPopover.openBy(oEvent.getSource());
		},

		onAfterRendering: function() {
			if (this._First) {
				this._First = false;
			}
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});