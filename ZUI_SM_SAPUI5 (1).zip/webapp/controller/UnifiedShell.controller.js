/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/Device"
], function(BaseController, MessageToast, JSONModel, History, Device) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.UnifiedShell", {

		onInit: function() {

			this.getRouter().getRoute("unifiedShell").attachPatternMatched(this._onObjectMatched, this);

			var oData = {
					logo: sap.ui.require.toUrl("com/spro/uismsapui5") + "/" + "/image/sap_50x26.png"
				},
				oModel = new JSONModel();

			oModel.setData(oData);
			this.getView().setModel(oModel);

		},

		handlePressConfiguration: function(oEvent) {
			var oItem = oEvent.getSource();
			var oShell = this.byId("myShell");
			var bState = oShell.getShowPane();
			oShell.setShowPane(!bState);
			oItem.setShowMarker(!bState);
			oItem.setSelected(!bState);
		},
		
		handleSearchItemSelect: function(oEvent) {
			MessageToast.show("Search Entry Selected: " + oEvent.getSource().getTitle());
		},

		handleSearchPressed: function(oEvent) {
			var sQuery = oEvent.getParameter("query");
			if (sQuery == "") {
				return;
			}

			// Create Overlay Only Once
			if (!this._overlay) {
				this._overlay = sap.ui.xmlfragment(
					"com.spro.uismsapui5.fragment.ShellOverlay",
					this
				);
				this.getView().addDependent(this._overlay);
			}

			// Mock Data
			var aResultData = [];
			for (var i = 0; i < 10; i++) {
				aResultData.push({
					title: (i + 1) + ". " + sQuery,
					text: "Lorem ipsum sit dolem"
				});
			}

			var oData = {
				searchFieldContent: sQuery,
				resultData: aResultData
			};

			// Set Fragment Data
			var oModel = new JSONModel();
			oModel.setData(oData);
			this._overlay.setModel(oModel);

			// Set Reference to Shell and Open Overlay
			this._overlay.setShell(this.byId("myShell"));
			this._overlay.open();
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});