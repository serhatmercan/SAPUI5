/*global history */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"com/spro/uismsapui5/model/formatter",
	"com/spro/uismsapui5/model/models"
], function(BaseController, JSONModel, History, Filter, FilterOperator, GroupHeaderListItem, Device, formatter, models) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.Menu", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function() {
			this._oHashChanger = this.getRouter().oHashChanger;
			this._First = true;
		},

		onAfterRendering: function() {
			if (this._First) {
				this._First = false;
			}
		},

		onUpdateFinished: function(oEvent) {
			this.selectMenuItem();
		},

		selectMenuItem: function() {
			if (!Device.system.phone) {
				var sHash = this._oHashChanger.getHash(),
					aMenu = this.getModel("menu").getData(),
					oList = this.byId("idList"),
					aItems = oList.getItems(),
					sIndex;
				if (aMenu.length > 0) {
					sIndex = aMenu.findIndex(x => x.pattern === sHash);
					this._SelectedItem = aItems.find(x => x.getBindingContextPath() === "/" + sIndex);
					oList.setSelectedItem(this._SelectedItem);
				}
			}
		},

		onMenuItemPress: function(oEvent) {
			this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		_showDetail: function(oItem) {
			var oMenu = oItem.getBindingContext("menu").getObject(),
				bReplace = !Device.system.phone,
				oList = this.byId("idList"),
				that = this;

			function navToCreate() {
				that.getRouter().oHashChanger.replaceHash("");
				that.getModel().resetChanges();
				that._SelectedItem = oItem;
				that.getRouter().navTo(oMenu.view, {}, bReplace);
			}

			function fnCancel() {
				oList.setSelectedItem(that._SelectedItem);
			}

			if (this.getModel().hasPendingChanges()) {
				models.getPendingChangesDialog(this, navToCreate, fnCancel);
			} else {
				this._SelectedItem = oItem;
				this.getRouter().navTo(oMenu.view, {}, bReplace);
			}
		}
	});

});