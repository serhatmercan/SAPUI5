/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/Device"
], function(BaseController, JSONModel, History, Device) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.UnifiedSplitContainer", {

		onInit: function() {

			this.getRouter().getRoute("unifiedSplitContainer").attachPatternMatched(this._onObjectMatched, this);

		},

		handleSwitchOrientation: function(oEvent) {
			var sOrientation = this.byId("mySplitContainer").getOrientation();
			if (sOrientation == "Vertical") {
				sOrientation = "Horizontal";
			} else {
				sOrientation = "Vertical";
			}
			this.byId("mySplitContainer").setOrientation(sOrientation);
		},

		handleToggleSecondaryContent: function(oEvent) {
			var oSplitContainer = this.byId("mySplitContainer");
			oSplitContainer.setShowSecondaryContent(!oSplitContainer.getShowSecondaryContent());
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});