/*global location */
sap.ui.define([
	"com/spro/uismsapui5/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/Device",
	"sap/gantt/misc/Format"
], function(BaseController, JSONModel, History, Device, Format) {
	"use strict";

	return BaseController.extend("com.spro.uismsapui5.controller.GanttChart", {

		onInit: function() {

			this.getRouter().getRoute("ganttChart").attachPatternMatched(this._onObjectMatched, this);
			
			var oModel = new JSONModel(sap.ui.require.toUrl("com/spro/uismsapui5/model/GanttChartData.json"));
			this.getView().setModel(oModel);

		},
		
		fnTimeConverter: function (sTimestamp) {
			return Format.abapTimestampToDate(sTimestamp);
		},

		_onObjectMatched: function(oEvent) {},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				bReplace = !Device.system.phone;
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("menu", {}, bReplace);
			}
		}
	});

});